
try:
    num = int(input('Digite um numero: '))
    y = 1/num
    print('Valor de y =',y)
except:
    print('ERRO: Não foi possivel executar a operação')
    
print('Programa foi encerrado')
