class Super2:
    
    def __init__(self):
        self.supVar = 11
        self.__hiddenVar = 33

class Sub(Super2):
    def __init__(self):
        super().__init__() # dispensa a passagem de self
        self.subVar = 22




obj = Sub()
print(obj.subVar) # acesso à variável de instância em Sub
print(obj.supVar) # acesso à variável de instância em Super2
obj2 = Super2()
print(obj2._Super2__hiddenVar) # acessando variavel privada em Super2 com Super2()
print(obj._Super2__hiddenVar) # acessando variavel privada em Super2 com Sub()


