from Transacao import *

class TEV(Transacao):

    def __init__( self, tipo, descricao, valor, contaDestino ):
        Transacao.__init__(self,tipo,descricao,valor)
        self.__contaDestino = contaDestino
        print(self.getValor())
 
 
    def getContaDestino(self):
        return self.__contaDestino

    # Overriding de método
    def setDescricao(self, novaDescricao):
        novaDescricao += f" para a conta {self.__contaDestino}"
        #Transacao.setDescricao(self,novaDescricao)
        super().setDescricao(novaDescricao)


t1 = Transacao("C","deposito",1500)
print("Superclasse (descricao):", t1.getDescricao())
t2 = TEV("D","Transferencia Eletronica de Valores",200.0,"4678")
print("Subclasse (Conta de Destino):", t2.getContaDestino())
print("Subclasse (acesso método superclasse):", t2.getDescricao())
# como o tipo, na superclasse, está publico, TEV pode acessa-lo
print(t2.tipo)

# tentando acessar getContaDestino() com t1
#print("Subclasse (Conta de Destino):", t1.getContaDestino())

# overriding na prática
t2.setDescricao("Transfer")
print("Descrição da Transação:", t2.getDescricao())

print(t2.__dict__)
#quebra de encapsulamento
print(t2._TEV__contaDestino)






