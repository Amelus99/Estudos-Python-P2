class Super3:
    SUPVAR = 1
    __SUPHIDDENVAR = 3

class Sub(Super3):
    SUBVAR = 2

obj = Sub() # não tem construtor
print(obj.SUBVAR) # propriedade de classe da subclasse
print(Sub.SUBVAR) # outra forma de acesso
print(obj.SUPVAR) # propriedade de classe da Superclasse
print(Super3.SUPVAR) # outra forma de acesso
print(obj._Super3__SUPHIDDENVAR) # propriedade de classe privada da Superclasse 


