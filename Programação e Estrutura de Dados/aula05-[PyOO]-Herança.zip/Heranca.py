class Superclasse:
    def __init__(self, x):
        self.x = x

    def message(self):
        print('Mensagem da SuperClasse')


    def getX(self):
        return self.x

class Subclasse(Superclasse):
    def __init__(self, x, y):
        Superclasse.__init__(self,x)
        self.x = - (x)
        self.y = y

    def message(self):
        print('Mensagem da SUBCLASSE')


obj1 = Superclasse(10)
obj2 = Subclasse(20,30)
obj1.message()
obj2.message()
print('(Sup) x =', obj1.getX())
print('(Sub) x =', obj2.getX())

print(Superclasse.
