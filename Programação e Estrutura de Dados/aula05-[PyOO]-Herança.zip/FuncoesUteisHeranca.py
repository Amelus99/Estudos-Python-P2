class Vehicle:
    pass

class LandVehicle(Vehicle):
    pass

class TrackedVehicle(LandVehicle):
    pass

# testando a função issubclass()
print('---------------- issubclass() -----------------')
print('                Vehicle         LandVehicle     TrackedVehicle')
for cl1 in [Vehicle, LandVehicle, TrackedVehicle]:
    print(f'{cl1.__name__:15s}\t',end="")
    for cl2 in [Vehicle, LandVehicle, TrackedVehicle]:
        print(f'{issubclass(cl1,cl2)}    ',end='\t')
    print()

print()
print('---------------- isinstance() -----------------')
print('                           Vehicle      LandVehicle     TrackedVehicle')
# testando a função isinstance()
vehicle = Vehicle()
landvehicle = LandVehicle()
trackedvehicle = TrackedVehicle()


for ob in [vehicle, landvehicle, trackedvehicle]:
    print(f'Object of {ob.__class__.__name__:15s}  ',end="")        
    for cl in [Vehicle, LandVehicle, TrackedVehicle]:
        print(f'{isinstance(ob,cl)}\t',end='\t')
    print()

