class Classe:
    def __init__(self,val):
        self.val = val

ob1 = Classe(0)
ob2 = Classe(2)
ob3 = ob1
ob3.val += 1
print(f'ob1 is ob2 = {ob1 is ob2}')
print(f'ob2 is ob3 = {ob2 is ob3}')
print(f'ob3 is ob1 = {ob3 is ob1}')
print(ob1.val, ob2.val, ob3.val)

str1 = "Mary had a little "
str2 = "Mary had a little lamb"
str1 += "lamb"
print(str1 == str2, str1 is str2)
