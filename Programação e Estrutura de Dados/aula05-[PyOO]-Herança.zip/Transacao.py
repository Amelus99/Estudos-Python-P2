class Transacao:
    def __init__( self, tipo, descricao, valor ):
        self.tipo = tipo
        self.descricao = descricao
        self.valor = valor
 

    def setValor(self, novoValor):
        self.valor = novoValor

    def getDescricao(self):
        return self.descricao

    def getValor(self):
        return self.valor

    def setDescricao(self, novaDescricao):
        self.descricao = novaDescricao


