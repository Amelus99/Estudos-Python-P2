class Super1:
    def __init__(self,nome):
        self.nome = nome

    def __str__(self):
        return 'Meu nome é ' + self.nome + "."

class Sub(Super1):
    def __init__(self,nome):
        super().__init__(nome) # dispensa a passagem de self


obj = Sub("Alex")
print(obj) # chamada automatica do __str__x



