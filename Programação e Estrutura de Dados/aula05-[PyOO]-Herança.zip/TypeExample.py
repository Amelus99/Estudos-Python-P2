class Super1:
    pass

class Super2:
    pass

class Sub(Super1, Super2):
    pass


setOfObjects = []
setOfObjects.append(Super1())
setOfObjects.append(Super2())
setOfObjects.append(Sub())

for obj in setOfObjects:
    print('Sem __name__:',type(obj)) 
    print('Com __name__:',type(obj).__name__)


