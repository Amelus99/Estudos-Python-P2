class Celular:
   def trocarBateria(self, novaBateria ):
      self.bateria = novaBateria
  
   def showBateria(self):
      print('Bateria:', self.bateria)

cel = Celular()
cel.trocarBateria("3000mA")
cel.showBateria()



