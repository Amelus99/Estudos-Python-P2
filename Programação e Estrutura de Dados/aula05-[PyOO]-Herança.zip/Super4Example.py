class Super4:
    
    def superMethod(self):
        print('Eu sou um método da SUPERclasse')


class Sub(Super4):
    def subMethod(self):
        print('Eu sou um método da SUBclasse')

    def subMethodAcces(self):
        print()
        # Chamar dessa forma com self
        self.superMethod()
        # Ou dessa com super()
        super().superMethod()
        print('chamado de dentro de um método da subclasse')
        

objSub = Sub()
objSup = Super4()


# uma referencia do tipo da subclasse, acessa métodos da superclasse e da subclasse
objSub.superMethod()
objSub.subMethod()

# Uma referência do tipo da superclasse não pode acessar um método de um de seus descendentes
#objSup.subMethod()

# Método da subclasse que chama internamente um método da superclasse
objSub.subMethodAcces()
