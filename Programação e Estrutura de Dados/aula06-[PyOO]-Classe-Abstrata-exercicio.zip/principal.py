from funcionario import *

g = Gerente("Hermano",1500)
g.setGrauInstrucao("Mestre")
p = Presidente("Steve Jobs",5000)
d = Diretor("Trump",2000)


for obj in [g,p,d]:
    obj.addBonificacao()
    print(f'{obj.getNome()} vai receber {obj.contracheque()}')
    
    print(obj,"\n")

